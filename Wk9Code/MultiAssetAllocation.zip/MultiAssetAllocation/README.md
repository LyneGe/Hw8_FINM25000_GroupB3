# Multi-Asset Allocation

FINM 25000 - Portfolio Construction exercise, Sections 1-3.

## Files
- `multi_asset_allocation.ipynb` - the solved exercise (run top to bottom, outputs are saved)
- `data/asset_class_etf_data.xlsx` - course data file
- `requirements.txt`

## Notes
- Weekly excess returns from the `excess returns` tab, annualized with a factor of 52.
- Section 3 estimates on data through 2021 only and drops BTC, per the instructions.
- Sections 4-6 are not included.

## Run
```
pip install -r requirements.txt
jupyter notebook multi_asset_allocation.ipynb
```
